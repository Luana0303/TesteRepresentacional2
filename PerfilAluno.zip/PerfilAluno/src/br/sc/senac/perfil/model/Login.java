package br.sc.senac.mcap.dao;

import br.sc.senac.mcap.model.Cliente;
import br.sc.senac.mcap.util.ConnectionFactory;
import br.sc.senac.perfil.model.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ClienteDao extends br.sc.senac.mcap.dao.Dao<Aluno> {

    @Override
    public boolean cadastrar(Aluno cliente) throws SQLException {
        PreparedStatement ps = null;

        String sql = "INSERT INTO cliente (cli_nome, cli_cpf, cli_sexo, cli_fone) VALUES (?,?,?,?)";

        try {
            Connection conn = ConnectionFactory.getConexao();
            try {
                ps = conn.prepareStatement(sql);

                ps.setString(1, cliente.getNome());
                ps.setString(2, cliente.getCpf());
                ps.setString(3, cliente.getSexo());
                ps.setString(4, cliente.getFone());

                ps.executeUpdate();
            } finally {
                try {
                    ConnectionFactory.closeConnection(conn, ps, null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean atualizar(Cliente pojo) throws SQLException {
        return false;
    }

    @Override
    public boolean excluir(Cliente pojo) throws SQLException {
        return false;
    }

    @Override
    public Integer getCodigo(Cliente pojo) throws SQLException {
        return null;
    }
}


