package br.sc.senac.perfil.controller;

import br.sc.senac.perfil.dao.LoginDao;
import br.sc.senac.perfil.model.Aluno;


import java.sql.SQLException;
import java.util.ArrayList;

public class LoginController {
    public ArrayList<Aluno> buscarLoginSenha() throws SQLException, ClassNotFoundException {
        return LoginDao.buscarLogin();
    }
}
