package br.sc.senac.perfil.controller;

import br.sc.senac.mcap.dao.ClienteDao;
import br.sc.senac.perfil.dao.Dao;
import br.sc.senac.perfil.model.Aluno;
import br.sc.senac.perfil.model.Aluno;

import java.sql.SQLException;

public class ClienteController extends Dao<Aluno> {
    @Override
    public boolean cadastrar(Aluno aluno) throws SQLException {
        boolean resultado = false;
        ClienteDao clienteDao = new ClienteDao();
        if (clienteDao.cadastrar(aluno)) {
            resultado = true;
        }
        return resultado;
    }

    @Override
    public boolean atualizar(Aluno aluno) throws SQLException {
        // Implemente a lógica de atualização do aluno aqui
        // Retorne true se for bem-sucedido
        return true;
    }

    @Override
    public boolean excluir(Aluno aluno) throws SQLException {
        // Implemente a lógica de exclusão do aluno aqui
        // Retorne true se for bem-sucedido
        return true;
    }

    @Override
    public Integer getCodigo(Aluno aluno) throws SQLException {
        // Implemente a lógica para obter o código do aluno aqui
        // Retorne o valor correto como um Integer
        return 0;
    }
}
