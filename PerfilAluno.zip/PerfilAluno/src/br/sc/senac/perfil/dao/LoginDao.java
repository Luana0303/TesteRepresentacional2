import br.sc.senac.perfil.model.Aluno;
import br.sc.senac.perfil.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LoginDao {

    public static ArrayList<Aluno> buscarLogin() throws SQLException {
        ArrayList<Aluno> loginAux = new ArrayList<>();
        String sql = "SELECT log_nome, log_senha FROM login";

        try (Connection conn = ConnectionFactory.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Aluno login = new Aluno();
                login.setNome(rs.getString("log_nome"));
                login.setDate(rs.getString("log_senha"));
                loginAux.add(login);
            }
        }

        return loginAux;
    }
}
