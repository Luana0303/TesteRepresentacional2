package br.sc.senac.perfil.dao;

import br.sc.senac.perfil.model.Aluno;
import br.sc.senac.perfil.util.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LoginDao {
    public static ArrayList<Aluno> buscarLogin() throws SQLException, ClassNotFoundException {
        ArrayList<Aluno> alunos = new ArrayList<>();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionUtil.getConnection();

            // Execute a consulta SQL para buscar os logins
            String sql = "SELECT * FROM alunos";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            // Iterar sobre o resultado e criar objetos Aluno
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String login = rs.getString("login");
                String senha = rs.getString("senha");

                Aluno aluno = new Aluno(id, nome, login, senha);
                alunos.add(aluno);
            }
        } finally {
            // Fechar as conexões, declarações e resultados
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return alunos;
    }
}
